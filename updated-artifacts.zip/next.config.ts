import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  eslint: {
    // Ignore ESLint errors during production build
    ignoreDuringBuilds: true,
  },
  typescript: {
    // Ignore TypeScript errors during production build
    ignoreBuildErrors: true,
  },
  // Configure output for AWS Amplify compatibility
  output: 'standalone',
  // Ensure trailing slashes are handled correctly
  trailingSlash: false,
  // Configure image domains if needed
  images: {
    domains: ['d30moqmwzk9i0o.amplifyapp.com'],
    unoptimized: true,
  },
};

export default nextConfig;
